
function archita_f1() {
    var amount_275 = parseFloat(document.getElementById('USD').value);

    if (isNaN(amount_275) || amount_275 <= 0 || amount_275 === null || amount_275 === "") {
        alert('Enter a valid amount.');
        return;
    }
    
    var exchange_rate_275 = 1.27;

    var converted_275 = (amount_275 * exchange_rate_275).toFixed(3);

    document.getElementById('CAD').value = converted_275;
    document.getElementById('CAD').focus();
}

function archita_f2() {
    var amount_275 = parseFloat(document.getElementById('CAD').value);

    if (isNaN(amount_275) || amount_275 <= 0 || amount_275 === null || amount_275 === "") {
        alert('Enter a valid amount.');
        return;
    }

    var exchange_rate_275 = 0.79;

    var converted_275 = (amount_275 * exchange_rate_275).toFixed(3);

    document.getElementById('USD').value = converted_275;
    document.getElementById('USD').focus();
}


